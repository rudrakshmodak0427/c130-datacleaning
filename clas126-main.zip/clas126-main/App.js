import React from "react";

import PickImage from "./screens/Camera.js";

export default class App extends React.Component {
  render() {
    return <PickImage/>;
  }
}
